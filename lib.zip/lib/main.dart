import 'package:flutter/material.dart';
import 'package:pos_task/app.dart';

void main() {
  runApp(App());
}
