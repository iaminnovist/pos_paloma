import 'package:flutter/material.dart';
import 'package:pos_task/core/database_helper.dart';
import 'package:pos_task/models/food.dart';

class AddToCartPage extends StatefulWidget {
  const AddToCartPage({super.key});

  @override
  State<AddToCartPage> createState() => _AddToCartPageState();
}

class _AddToCartPageState extends State<AddToCartPage> {
 
  final List<Food> foods = [
    Food(name: 'Chicken (Grilled) Bento Box', price: 17.0),
    Food(name: 'Chicken Tempura Bento Box', price: 17.0),
    Food(name: 'Fried Tofu Bento Box', price: 15.0),
    Food(name: 'Salmon Bento Box', price: 16.0),
    Food(name: 'Shrimp (Tempura) Bento Box', price: 17.0),
    Food(name: 'Shrimp (Grilled) Bento Box', price: 17.0),
    Food(name: 'Steak Bento Box', price: 18.0),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       
      appBar: AppBar(
        // leading: Icon(Icons.chevron_left),
        title: const Text('Bento Box'),
      ),
      body: Column(
        children: [
          Expanded(
            child: GridView.builder(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              itemCount: foods.length,
              padding: const EdgeInsets.all(10),
              itemBuilder: (context, index) {
                final food = foods[index];
                return GestureDetector(
                  onTap: () {
                    //context.read<FoodBloc>().add(AddFoodEvent(food));
                  },
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(food.name, textAlign: TextAlign.center),
                        const SizedBox(height: 10),
                        Text('\$${food.price}',
                            style: const TextStyle(fontWeight: FontWeight.bold))
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
          ElevatedButton(
            onPressed: () => _showBentoBoxBottomSheet(context),
            child: Text('View Stored Foods'),
          ),
        ],
      ),
    );
  }

  void _showBentoBoxBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return BentoBoxBottomSheet();
      },
    );
  }
}
class BentoBoxBottomSheet extends StatelessWidget {
  final List<Map<String, dynamic>> bentoBoxes = [
    {"name": "CHICKEN (GRILLED) BENTO BOX", "price": "17.0", "image": ""},
    {"name": "CHICKEN TEMPURA BENTO BOX", "price": "17.0", "image": ""},
    {"name": "FRIED TOFU BENTO BOX", "price": "15.0", "image": ""},
    {"name": "GRILLED TOFU BENTO BOX", "price": "15.0", "image": ""},
    {"name": "SALMON BENTO BOX", "price": "16.0", "image": ""},
    {"name": "SHRIMP (GRILLED) BENTO BOX", "price": "17.0", "image": ""},
    {"name": "SHRIMP (TEMPURA) BENTO BOX", "price": "17.0", "image": ""},
    {"name": "STEAK BENTO BOX", "price": "18.0", "image": ""},
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.60,
      padding: EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            children: [
              IconButton(
                icon: Icon(Icons.arrow_back),
                onPressed: () => Navigator.pop(context),
              ),
              Text(
                "BENTO BOX",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              Spacer(),
              Icon(Icons.qr_code, size: 24),
              SizedBox(width: 10),
              Icon(Icons.search, size: 24),
            ],
          ),
          Expanded(
            child: GridView.builder(
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 2.8,
                crossAxisSpacing: 8,
                mainAxisSpacing: 8,
              ),
              itemCount: bentoBoxes.length,
              itemBuilder: (context, index) {
                final item = bentoBoxes[index];
                return BentoBoxCard(
                  name: item["name"],
                  price: item["price"],
                  image: item["image"],
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class BentoBoxCard extends StatelessWidget {
  final String name;
  final String price;
  final String image;

  const BentoBoxCard({super.key, required this.name, required this.price, required this.image});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Row(
        children: [
          Container(
            width: 80,
            height: double.infinity,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.horizontal(left: Radius.circular(10)),
            ),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                Spacer(),
                Text(
                  "\$${price}",
                  style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}